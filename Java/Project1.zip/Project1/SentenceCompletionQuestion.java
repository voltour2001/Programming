import java.util.List;

public class SentenceCompletionQuestion extends Question {

    
    //! Constructor
    public SentenceCompletionQuestion(String code, String description) {
        super(code, description);
        //* Additional initialization if needed
    }

    @Override
    public boolean isCorrect(List<String> userResponse) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'isCorrect'");
    }

    
}